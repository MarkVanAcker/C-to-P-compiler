int a = 3;
for(;a<7;a=a+1){
    int i;
    i = a+1;
}
