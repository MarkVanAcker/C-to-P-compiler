int *a = 10;
