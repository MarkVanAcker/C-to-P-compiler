float function (int a, float b, char c){
    int a = a + 3;
    return a;
}

float func () {
    return 1.0;
}
