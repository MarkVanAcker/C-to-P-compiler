int doSomething(){
    return 3;
}
if( 7 < doSomething() -2 ){
    doSomething();
}
