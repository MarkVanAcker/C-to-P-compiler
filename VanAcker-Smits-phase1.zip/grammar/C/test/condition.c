char a = 'c';
if (a){
    char d;
}
