int a,b,c,d = 6;
char f(int), c ,d ;
void  * a, b[3];
int f(int,float,char);
float func(int a, float b, char c);
