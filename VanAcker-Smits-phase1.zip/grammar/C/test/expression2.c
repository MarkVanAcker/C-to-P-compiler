int a = 5+3/2;
