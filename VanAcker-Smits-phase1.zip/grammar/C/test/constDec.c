const int a;
const const int b = 5;
const const int const const c = 10;
