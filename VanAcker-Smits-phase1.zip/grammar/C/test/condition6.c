void doSomething(){}

if (5 > 4) doSomething();
else return 'goed';
