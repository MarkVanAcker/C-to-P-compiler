float d;
if( d ){
    return 1;
}else{
    return;
}
