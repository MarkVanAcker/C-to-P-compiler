#include <stdio.h>

int a = 0;
for(;;a=a+10){
    printf(a);
}
