int f(int c){
    return c;
}

if ( f(3) ){
    return ;
}
else if ( f(4) ) {
    return 1;
}else{
    return 0;
}
