int b[5];
int a = b[3] + 3 - f(i+2) * 3 + (a*b);
