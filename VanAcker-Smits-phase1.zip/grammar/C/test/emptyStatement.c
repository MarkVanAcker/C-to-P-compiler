int function(float a){
    ;;;
    return a-a;
}
