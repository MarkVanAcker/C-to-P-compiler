int *a;
float b;
char c;
void d;
