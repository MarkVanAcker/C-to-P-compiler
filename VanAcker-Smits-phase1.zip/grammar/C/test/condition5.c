int a = 4;
if( a ) return 0;
