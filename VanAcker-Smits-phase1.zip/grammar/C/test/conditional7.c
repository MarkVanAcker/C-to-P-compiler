int a =5;
float i = 7.0;
if ( a ) return 'oeps';
else ;
